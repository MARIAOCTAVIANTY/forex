package com.mariaoctavianty.forex;

public class RatesModel
{
    private double AUD, IDR, EUR, SGD, CHF, JPY, KRW, MYR, RON, TRY;

    public RatesModel() {}

    public double getAUD() { return AUD; }

    public void setAUD(double AUD) { this.AUD = AUD; }

    public double getIDR() { return IDR; }

    public void setIDR(double IDR) { this.IDR = IDR; }

    public double getEUR() { return EUR; }

    public void setEUR(double EUR) {  this.EUR = EUR; }

    public double getSGD() { return SGD; }

    public void setSGD(double SGD) { this.SGD = SGD; }

    public double getCHF() { return CHF; }

    public void setCHF(double CHF) { this.CHF = CHF; }

    public double getJPY() { return JPY; }

    public void setJPY(double JPY) { this.JPY = JPY; }

    public double getKRW() { return KRW; }

    public void setKRW(double KRW) { this.KRW = KRW; }

    public double getMYR() { return MYR; }

    public void setMYR(double MYR) { this.MYR = MYR; }

    public double getRON() { return RON; }

    public void setRON(double RON) { this.RON = RON; }

    public double getTRY() { return TRY; }

    public void setTRY(double TRY) { this.TRY = TRY; }
}
