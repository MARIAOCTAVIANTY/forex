package com.mariaoctavianty.forex;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private ProgressBar loadingProgressBar;
    private SwipeRefreshLayout swipeRefreshLayout1;
    private TextView audTextView, idrTextView, eurTextview, sgdTextView, chfTextView, jpyTextView, krwTextView, myrTextView, ronTextView, tryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipeRefreshLayout1 = (SwipeRefreshLayout)findViewById(R.id.swipeRefreshLayout1);
        audTextView = (TextView)findViewById(R.id.audTextView);
        idrTextView = (TextView)findViewById(R.id.idrTextView);
        eurTextview = (TextView)findViewById(R.id.eurTextView);
        sgdTextView = (TextView)findViewById(R.id.sgdTextView);
        chfTextView = (TextView)findViewById(R.id.chfTextView);
        jpyTextView = (TextView)findViewById(R.id.jpyTextView);
        krwTextView = (TextView)findViewById(R.id.krwTextView);
    }
}